package com.notesexchange.model;

public enum AccessLevel {
    PUBLIC, DEPARTMENT, PRIVATE
}