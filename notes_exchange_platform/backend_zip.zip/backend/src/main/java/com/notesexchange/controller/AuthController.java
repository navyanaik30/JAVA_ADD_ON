package com.notesexchange.controller;

import com.notesexchange.dto.ApiResponse;
import com.notesexchange.dto.LoginRequest;
import com.notesexchange.dto.SignupRequest;
import com.notesexchange.model.User;
import com.notesexchange.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    
    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@RequestBody LoginRequest loginRequest) {
        try {
            Optional<User> userOptional = authService.loginUser(loginRequest.getEmail(), loginRequest.getPassword());
            
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                // Remove password from response
                user.setPassword(null);
                return ResponseEntity.ok(new ApiResponse(true, "Login successful", user));
            } else {
                return ResponseEntity.ok(new ApiResponse(false, "Invalid email or password"));
            }
        } catch (Exception e) {
            return ResponseEntity.ok(new ApiResponse(false, "Login failed: " + e.getMessage()));
        }
    }

    @PostMapping("/signup")
    public ResponseEntity<ApiResponse> signup(@RequestBody SignupRequest signupRequest) {
        try {
            User user = authService.registerUser(
                signupRequest.getEmail(),
                signupRequest.getPassword(),
                signupRequest.getFirstName(),
                signupRequest.getLastName(),
                signupRequest.getUserType(),
                signupRequest.getDepartment()
            );
            
            // Remove password from response
            user.setPassword(null);
            return ResponseEntity.ok(new ApiResponse(true, "Registration successful", user));
            
        } catch (Exception e) {
            return ResponseEntity.ok(new ApiResponse(false, "Registration failed: " + e.getMessage()));
        }
    }
}