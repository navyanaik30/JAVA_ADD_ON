package com.notesexchange.model;

public enum UserType {
    STUDENT, SENIOR, FACULTY
}